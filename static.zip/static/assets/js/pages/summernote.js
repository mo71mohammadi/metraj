$(".summernote").summernote({
    airMode: false,
    direction: "rtl",
    fontNames: ['Tahoma', 'B Nazanin', 'B Yekan', 'Parastoo', 'Arial', 'IranSans' ],
    fontNamesIgnoreCheck: ['Tahoma', 'B Nazanin', 'B Yekan', 'Parastoo', 'Arial', 'IranSans' ]
});